<?
$arModuleVersion = array(
    "VERSION" => "1.3.4",
    "VERSION_DATE" => "2025-07-18 06:41:00"
);
?>