<?
$arModuleVersion = array(
    "VERSION" => "1.2.6",
    "VERSION_DATE" => "2025-04-26 13:05:00"
);
?>