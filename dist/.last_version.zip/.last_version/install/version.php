<?
$arModuleVersion = array(
    "VERSION" => "1.3.2",
    "VERSION_DATE" => "2025-06-21 13:32:00"
);
?>