<?
$arModuleVersion = array(
    "VERSION" => "1.3.5",
    "VERSION_DATE" => "2025-07-26 16:20:00"
);
?>