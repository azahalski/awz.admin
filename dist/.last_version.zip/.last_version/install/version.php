<?
$arModuleVersion = array(
    "VERSION" => "1.2.10",
    "VERSION_DATE" => "2025-06-13 20:11:00"
);
?>