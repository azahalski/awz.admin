<?
$arModuleVersion = array(
    "VERSION" => "1.2.7",
    "VERSION_DATE" => "2025-06-07 05:01:00"
);
?>