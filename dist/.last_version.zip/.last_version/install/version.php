<?
$arModuleVersion = array(
    "VERSION" => "1.3.1",
    "VERSION_DATE" => "2025-06-21 13:25:00"
);
?>