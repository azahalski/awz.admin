<?
$arModuleVersion = array(
    "VERSION" => "1.2.8",
    "VERSION_DATE" => "2025-06-09 13:34:00"
);
?>