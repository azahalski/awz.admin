<?
$arModuleVersion = array(
    "VERSION" => "1.3.3",
    "VERSION_DATE" => "2025-07-18 05:51:00"
);
?>