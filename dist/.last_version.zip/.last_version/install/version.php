<?
$arModuleVersion = array(
    "VERSION" => "1.3.0",
    "VERSION_DATE" => "2025-06-21 13:11:00"
);
?>