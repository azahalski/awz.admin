<?
$arModuleVersion = array(
    "VERSION" => "1.2.12",
    "VERSION_DATE" => "2025-06-14 00:11:00"
);
?>