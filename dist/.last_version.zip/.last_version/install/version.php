<?
$arModuleVersion = array(
    "VERSION" => "1.3.6",
    "VERSION_DATE" => "2025-11-12 15:14:00"
);
?>