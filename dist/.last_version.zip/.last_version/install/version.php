<?
$arModuleVersion = array(
    "VERSION" => "1.2.11",
    "VERSION_DATE" => "2025-06-13 20:11:00"
);
?>