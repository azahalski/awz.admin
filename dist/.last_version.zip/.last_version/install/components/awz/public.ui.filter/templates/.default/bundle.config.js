module.exports = {
	input: './src/main.ui.filter.js',
	output: {
		js: './script.js',
		css: './style.css',
	},
	namespace: 'BX.Filter',
	adjustConfigPhp: false,
};