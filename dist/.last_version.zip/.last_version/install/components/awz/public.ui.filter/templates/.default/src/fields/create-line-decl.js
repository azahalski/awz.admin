export default function createLineDecl()
{
	return {
		block: 'main-ui-filter-field-line',
		content: {
			block: 'main-ui-filter-field-line-item',
			tag: 'span',
		},
	};
}