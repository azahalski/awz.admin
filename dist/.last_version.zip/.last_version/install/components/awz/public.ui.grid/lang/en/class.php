<?php
$MESS["GRID_COLUMNS_INCORRECT"] = "The COLUMNS parameter is incorrect. It must specify a column array.";
$MESS["GRID_ID_INCORRECT"] = "GRID_ID is incorrect. It must be a non-empty string, for example: \"bitrix_example_grid\"";
$MESS["interface_grid_check"] = "Mark for editing";
$MESS["interface_grid_dblclick"] = "Double-click -";
$MESS["interface_grid_default_view"] = "<Default View>";
