<?php
$MESS["GRID_COLUMNS_INCORRECT"] = "Der Parameter COLUMNS ist nicht korrekt. Er muss ein Bereich von Spalten sein.";
$MESS["GRID_ID_INCORRECT"] = "GRID_ID ist nicht korrekt. Es muss eine nicht leere Zeile sein, z.B.: \"bitrix_example_grid\"";
$MESS["interface_grid_check"] = "Zum Bearbeiten markieren";
$MESS["interface_grid_dblclick"] = "Doppel-Klick";
$MESS["interface_grid_default_view"] = "<Standardansicht>";
