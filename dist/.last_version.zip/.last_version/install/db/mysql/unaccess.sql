drop table if exists awz_admin_role;
drop table if exists awz_admin_role_relation;
drop table if exists awz_admin_permission;