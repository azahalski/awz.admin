<?php
###lockdelete
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.admin/admin/gens_list.php");