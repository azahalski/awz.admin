<?php
namespace Awz\Admin;

class Parameters extends Dict\Parameters {

    public function __construct(array $params = array())
    {
        parent::__construct($params);
    }

}