<?php
namespace Awz\Admin\Access\Custom;

class Helper
{
    public const ADMIN_DECLINE = 1;
}